inv_metric <- 
structure(c(1),
.Dim = c(1, 1))
