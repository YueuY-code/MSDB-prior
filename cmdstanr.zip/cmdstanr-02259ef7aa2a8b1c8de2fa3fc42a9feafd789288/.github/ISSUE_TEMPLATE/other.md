---
name: Other
about: Issues that don't fit under "Bug report" or "Feature request"
title: ''
labels: ''
assignees: ''

---

**Describe the issue**


**CmdStanR version number**
Your CmdStanR version number (e.g. from `packageVersion("cmdstanr")`).
