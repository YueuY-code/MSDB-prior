#' @seealso
#' The CmdStanR website
#' ([mc-stan.org/cmdstanr](https://mc-stan.org/cmdstanr/)) for online
#' documentation and tutorials.
#'
#' The Stan and CmdStan documentation:
#' * Stan documentation: [mc-stan.org/users/documentation](https://mc-stan.org/users/documentation/)
#' * CmdStan User’s Guide: [mc-stan.org/docs/cmdstan-guide](https://mc-stan.org/docs/cmdstan-guide/)
#'
